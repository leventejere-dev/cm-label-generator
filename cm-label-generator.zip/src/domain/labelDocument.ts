/**
 * A4 LABEL DOCUMENT MODEL
 * ---------------------------------------------------------------------------
 * A layout-independent description of the finished Color Metal label.
 *
 * Two renderers consume this same model, which is why it exists:
 *   • features/label/A4Label.tsx  — the on-screen preview and the print output
 *   • features/label/pdfExport.ts — the vector PDF (pdf-lib, real text)
 *
 * Rules implemented here:
 *   • empty fields and empty sections are never emitted
 *   • the most important values are promoted into a hero block so they can be
 *     read from a distance in a warehouse
 *   • Color Metal's own delivery details lead the sheet, the way the labels
 *     currently produced by hand do
 *   • the supplier render-guard runs over every row before it is returned
 */

import { type ExtractionResult, type FieldMap, type FieldValue } from './extraction';
import {
  FIELD_GROUPS,
  type FieldGroupId,
  type LabelLanguage,
  describeField,
  fieldsInGroup,
  groupTitle,
  isGroupOmittedFromLabel,
  isSupplierCodeCaption,
  printCaption,
} from './fields';
import { assertNoSupplierLeak, type RemovedItem } from './sanitize';

export interface LabelRow {
  key: string;
  label: string;
  value: string;
}

export interface LabelSection {
  id: string;
  title: string;
  rows: LabelRow[];
}

export interface HeroMetric {
  label: string;
  value: string;
}

export interface LabelStrings {
  documentTitle: string;
  cmIdLabel: string;
  deliveryTitle: string;
}

export interface LabelDocument {
  cmId: string;
  /** ISO timestamp of generation. */
  generatedAt: string;
  language: LabelLanguage;
  strings: LabelStrings;
  /** Color Metal's own client / ship-to block, printed at the top. */
  delivery: LabelRow[];
  /** Big first line, e.g. "ANGLE / L-PROFILE". */
  headline: string | null;
  /** Big second line, e.g. "50 × 50 × 2.0". */
  subheadline: string | null;
  /** Short descriptors printed as chips: material, alloy, temper, finish. */
  descriptors: LabelRow[];
  /** Up to four large figures. */
  metrics: HeroMetric[];
  sections: LabelSection[];
  /**
   * Diagnostics for the operator's SCREEN only. Never rendered on the sheet:
   * a note saying "codes from the supplier's original label were not copied"
   * would itself tell the customer that a supplier label existed.
   */
  internalNotes: string[];
  footer: {
    companyLine: string;
    generatedAtLabel: string;
  };
}

export interface BuildLabelOptions {
  cmId: string;
  generatedAt?: Date;
  companyLine: string;
  language?: LabelLanguage;
  /** Used by the final render guard. */
  removed?: RemovedItem[];
  locale?: string;
}

const STRINGS: Record<LabelLanguage, LabelStrings> = {
  en: {
    documentTitle: 'MATERIAL LABEL',
    cmIdLabel: 'Color Metal ID',
    deliveryTitle: 'Delivery',
  },
  ro: {
    documentTitle: 'ETICHETĂ MATERIAL',
    cmIdLabel: 'ID Color Metal',
    deliveryTitle: 'Livrare',
  },
};

const NOTES: Record<LabelLanguage, { withheld: (n: number) => string; codes: string }> = {
  en: {
    withheld: (n) => `${n} field${n === 1 ? '' : 's'} were withheld by the supplier-information guard.`,
    codes: 'Codes printed on the original supplier label are not reproduced here.',
  },
  ro: {
    withheld: (n) => `${n} câmp${n === 1 ? '' : 'uri'} au fost reținute de filtrul de informații despre furnizor.`,
    codes: 'Codurile tipărite pe eticheta originală a furnizorului nu sunt reproduse aici.',
  },
};

function text(field: FieldValue | null | undefined): string | null {
  if (!field) return null;
  const value = field.value.trim();
  return value.length > 0 ? value : null;
}

function pick(map: FieldMap, key: string): string | null {
  return text(map[key]);
}

/** Compose a dimension string from parts when the label had no single one. */
function composeDimensions(product: FieldMap): string | null {
  const explicit = pick(product, 'dimensions');
  if (explicit) return explicit;
  const parts = [pick(product, 'thickness'), pick(product, 'width'), pick(product, 'length')].filter(
    (part): part is string => part !== null,
  );
  if (parts.length < 2) return null;
  return parts.join(' × ');
}

export function formatGeneratedAt(date: Date, locale = 'en-GB'): string {
  const datePart = new Intl.DateTimeFormat(locale, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
  const timePart = new Intl.DateTimeFormat(locale, {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);
  return `${datePart} ${timePart}`;
}

/**
 * Build the printable document from reviewed, already-sanitised data.
 * `data` must be the OUTPUT of colorMetalize() (or reviewer-edited data derived
 * from it) — this function only runs the final leak guard.
 */
export function buildLabelDocument(
  data: ExtractionResult,
  options: BuildLabelOptions,
): LabelDocument {
  const generatedAt = options.generatedAt ?? new Date();
  const language: LabelLanguage = options.language ?? 'ro';
  const strings = STRINGS[language];
  const locale = options.locale ?? (language === 'ro' ? 'ro-RO' : 'en-GB');
  const product = data.product;

  // --- delivery block -------------------------------------------------------
  const delivery: LabelRow[] = [];
  for (const descriptor of fieldsInGroup('delivery')) {
    const value = pick(data.delivery, descriptor.key);
    if (!value) continue;
    delivery.push({
      key: `delivery.${descriptor.key}`,
      label: printCaption(descriptor, language),
      value,
    });
  }

  // --- hero -----------------------------------------------------------------
  const headline =
    pick(product, 'productType') ?? pick(product, 'profileType') ?? pick(product, 'material');
  const subheadline = composeDimensions(product);

  const descriptors: LabelRow[] = [];
  for (const key of ['material', 'alloy', 'temper', 'finish', 'standard'] as const) {
    const value = pick(product, key);
    if (!value) continue;
    if (value === headline) continue;
    const descriptor = describeField(key);
    descriptors.push({
      key,
      label: descriptor ? printCaption(descriptor, language) : key,
      value,
    });
  }

  const metrics: HeroMetric[] = [];
  const metricCaption = (key: string, fallback: string) => {
    const descriptor = describeField(key);
    return descriptor ? printCaption(descriptor, language) : fallback;
  };

  const pieces = pick(data.quantity, 'pieces');
  const quantity = pick(data.quantity, 'quantity');
  const unit = pick(data.quantity, 'unit');
  if (pieces) {
    metrics.push({ label: metricCaption('pieces', 'Pieces'), value: pieces });
  } else if (quantity) {
    metrics.push({
      label: `${metricCaption('quantity', 'Quantity')}${unit ? ` (${unit})` : ''}`,
      value: quantity,
    });
  }
  const netWeight = pick(data.quantity, 'netWeight');
  if (netWeight) metrics.push({ label: metricCaption('netWeight', 'Net weight'), value: netWeight });
  const grossWeight = pick(data.quantity, 'grossWeight');
  if (grossWeight) metrics.push({ label: metricCaption('grossWeight', 'Gross weight'), value: grossWeight });
  const length = pick(product, 'length');
  if (length && metrics.length < 4) {
    metrics.push({ label: metricCaption('length', 'Length'), value: length });
  }

  // --- detail sections ------------------------------------------------------
  const sections: LabelSection[] = [];
  for (const group of FIELD_GROUPS) {
    if (group === 'delivery') continue; // rendered as its own block
    if (isGroupOmittedFromLabel(group)) continue; // procurement data stays internal

    const rows: LabelRow[] = [];
    for (const descriptor of fieldsInGroup(group)) {
      if (descriptor.omitFromLabel) continue;
      const value = pick(data[group] as FieldMap, descriptor.key);
      if (!value) continue;
      rows.push({
        key: `${group}.${descriptor.key}`,
        label: printCaption(descriptor, language),
        value,
      });
    }
    for (const extra of data.additionalFields) {
      if (extra.group !== group) continue;
      if (isSupplierCodeCaption(extra.label) || isSupplierCodeCaption(extra.key)) continue;
      const value = extra.value.trim();
      if (!value) continue;
      rows.push({ key: `additional.${extra.key}`, label: extra.label, value });
    }
    if (rows.length === 0) continue;
    sections.push({ id: group, title: groupTitle(group as FieldGroupId, language), rows });
  }

  const looseRows: LabelRow[] = data.additionalFields
    .filter((extra) => extra.group === 'additional')
    .filter((extra) => !isSupplierCodeCaption(extra.label) && !isSupplierCodeCaption(extra.key))
    .map((extra) => ({
      key: `additional.${extra.key}`,
      label: extra.label,
      value: extra.value.trim(),
    }))
    .filter((row) => row.value.length > 0);
  if (looseRows.length > 0) {
    sections.push({
      id: 'additional',
      title: language === 'ro' ? 'Informații suplimentare' : 'Additional information',
      rows: looseRows,
    });
  }

  // --- final supplier leak guard -------------------------------------------
  const removed = options.removed ?? [];
  const internalNotes: string[] = [];
  let leakedCount = 0;

  const guardedSections: LabelSection[] = [];
  for (const section of sections) {
    const { rows, leaked } = assertNoSupplierLeak(section.rows, removed);
    leakedCount += leaked.length;
    if (rows.length > 0) guardedSections.push({ ...section, rows });
  }
  const guardedDescriptors = assertNoSupplierLeak(descriptors, removed);
  leakedCount += guardedDescriptors.leaked.length;
  const guardedDelivery = assertNoSupplierLeak(delivery, removed);
  leakedCount += guardedDelivery.leaked.length;

  if (leakedCount > 0) internalNotes.push(NOTES[language].withheld(leakedCount));
  if (data.codes.qrCodes > 0 || data.codes.barcodes > 0) internalNotes.push(NOTES[language].codes);

  return {
    cmId: options.cmId,
    generatedAt: generatedAt.toISOString(),
    language,
    strings,
    delivery: guardedDelivery.rows,
    headline: headline ? headline.toUpperCase() : null,
    subheadline,
    descriptors: guardedDescriptors.rows,
    metrics: metrics.slice(0, 4),
    sections: guardedSections,
    internalNotes,
    footer: {
      companyLine: options.companyLine,
      generatedAtLabel: formatGeneratedAt(generatedAt, locale),
    },
  };
}

/** Anything worth printing at all? Guards against generating a blank sheet. */
export function labelHasContent(doc: LabelDocument): boolean {
  return (
    doc.sections.some((section) => section.rows.length > 0) ||
    doc.metrics.length > 0 ||
    doc.delivery.length > 0 ||
    doc.headline !== null
  );
}

/** Compact one-line summaries used by the Recent Labels list. */
export interface LabelSummary {
  product: string | null;
  dimensions: string | null;
  weight: string | null;
}

export function summarise(data: ExtractionResult): LabelSummary {
  const product =
    pick(data.product, 'productType') ??
    pick(data.product, 'material') ??
    pick(data.product, 'profileType');
  return {
    product,
    dimensions: composeDimensions(data.product),
    weight: pick(data.quantity, 'netWeight') ?? pick(data.quantity, 'grossWeight'),
  };
}
