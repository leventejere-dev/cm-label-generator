import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { applyBrandTokens } from './branding/brand';

import './styles/tokens.css';
import './styles/base.css';
import './styles/label.css';
import './styles/print.css';

applyBrandTokens();

const container = document.getElementById('root');
if (!container) throw new Error('Root element #root not found');

createRoot(container).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
